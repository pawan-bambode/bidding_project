module.exports = {
    getCourseworkload : (req, res) => {
        res.render('admin/courseworkload/index.ejs');
    }
}