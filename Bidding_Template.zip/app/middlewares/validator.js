

module.exports =  function validator(req, res){
console.log('req:::::::::::>>',req)
// switch(1){
//     case 1:return expression;
// }
}